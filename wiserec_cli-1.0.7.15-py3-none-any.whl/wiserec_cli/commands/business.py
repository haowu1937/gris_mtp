"""部门、租户（服务）和团队上下文命令。"""

from __future__ import annotations

from dataclasses import replace
from typing import Callable, List, Optional, Sequence, Tuple, TypeVar
from unicodedata import normalize

import typer

from .. import messages as msg
from ..business import BusinessSelection, Team
from ..errors import BusinessError
from ..output import console, print_result
from .. import ping
from .common import fail, runtime_from_context


business_app = typer.Typer(no_args_is_help=True, help="管理部门、租户和团队")
T = TypeVar("T")


class _Back(Exception):
    """返回交互选择的上一级。"""


class _Cancel(Exception):
    """取消交互选择且不保存。"""


def _credentials_and_catalog(context: typer.Context):
    runtime = runtime_from_context(context)
    credentials = runtime.auth.status()
    catalog = runtime.business.catalog(
        runtime.config.current_name, credentials.username
    )
    return runtime, credentials, catalog


def _print_selection(selection: BusinessSelection) -> None:
    print_result(
        {
            "type（选择维度）": selection.type,
            "department（部门）": selection.department_name,
            "tenant（租户）": selection.tenant_name,
            "team（团队）": selection.team_name or "-",
            "businessId": selection.business_id,
        }
    )


def _choose(
    title: str,
    values: Sequence[Tuple[str, T]],
    style_for: Optional[Callable[[T], Optional[str]]] = None,
) -> T:
    if not values:
        raise BusinessError(f"没有可选择的{title}")
    msg.detail(f"请选择{title}：")
    for index, (label, value) in enumerate(values, start=1):
        style = style_for(value) if style_for else None
        console.print(
            f"  {index}. {label}",
            style=style,
            markup=False,
            highlight=False,
        )
    selected_text = msg.prompt("请输入序号（b 返回，q 取消）").strip().lower()
    if selected_text == "b":
        raise _Back()
    if selected_text == "q":
        raise _Cancel()
    try:
        selected = int(selected_text)
    except ValueError as exc:
        raise BusinessError(f"{title}序号无效: {selected_text}") from exc
    if selected < 1 or selected > len(values):
        raise BusinessError(f"{title}序号无效: {selected}")
    return values[selected - 1][1]


def _department_matches(name: str, department_id: str, keyword: str) -> bool:
    query = normalize("NFKC", keyword).casefold()
    return any(
        query in normalize("NFKC", value).casefold()
        for value in (name, department_id)
    )


@business_app.command("list")
def list_businesses(context: typer.Context) -> None:
    """显示当前环境可见的部门、租户和团队目录。"""
    try:
        runtime, credentials, catalog = _credentials_and_catalog(context)
        selected = runtime.business.selection(
            runtime.config.current_name, credentials.username
        )
        for department in catalog:
            console.print(
                f"部门: {department.name} [{department.id}]", markup=False
            )
            for tenant in department.tenants:
                tenant_marker = (
                    " *当前"
                    if selected
                    and selected.type == "tenant"
                    and selected.department_id == department.id
                    and selected.tenant_id == tenant.id
                    else ""
                )
                console.print(
                    f"  租户: {tenant.name} [{tenant.id}]{tenant_marker}",
                    markup=False,
                )
                for team in tenant.teams:
                    team_marker = (
                        " *当前"
                        if selected
                        and selected.type == "team"
                        and selected.department_id == department.id
                        and selected.tenant_id == tenant.id
                        and selected.team_id == team.id
                        else ""
                    )
                    availability = (
                        "可选" if team.selectable else f"禁选: {team.status}"
                    )
                    console.print(
                        f"    团队: {team.name} [{team.id}] "
                        f"({availability}){team_marker}",
                        markup=False,
                    )
    except Exception as exc:
        fail(exc)


@business_app.command("show")
def show_business(context: typer.Context) -> None:
    """显示当前租户或团队上下文。"""
    try:
        runtime = runtime_from_context(context)
        credentials = runtime.auth.status()
        selection = runtime.business.require_selection(
            runtime.config.current_name, credentials.username
        )
        _print_selection(selection)
    except Exception as exc:
        fail(exc)


@business_app.command("use")
def use_business(
    context: typer.Context,
    tenant: Optional[str] = typer.Option(
        None, "--tenant", help="租户 ID（ai-businessList[].value）"
    ),
    team: Optional[str] = typer.Option(
        None, "--team", help="团队 ID 或 key"
    ),
    department: Optional[str] = typer.Option(
        None, "--department", help="部门 ID，用于消除重复租户 ID 歧义"
    ),
    search: Optional[str] = typer.Option(
        None, "--search", help="按部门名称或 ID 的关键词筛选交互列表"
    ),
) -> None:
    """交互式或通过 ID 选择租户/团队。"""
    try:
        runtime, credentials, catalog = _credentials_and_catalog(context)
        selected_tenant = tenant
        selected_team = team or ""
        selected_department = department or ""

        if search is not None:
            if tenant is not None:
                raise BusinessError("--search 用于交互选择部门，不能与 --tenant 同时使用")
            search = search.strip()
            if not search:
                raise BusinessError("--search 关键词不能为空")

        if tenant is None:
            if team is not None or department is not None:
                raise BusinessError(
                    "不能仅选择部门或团队，请同时通过 --tenant 指定租户"
                )
            departments = [
                item for item in catalog
                if search is None or _department_matches(item.name, item.id, search)
            ]
            if search is not None and not departments:
                raise BusinessError(
                    f"没有找到匹配 {search!r} 的部门，请更换关键词或不带 --search 查看全部部门"
                )
            labels = [
                (item.name if search is None or item.id == item.name
                 else f"{item.name} [{item.id}]", item)
                for item in departments
            ]
            stage = 0
            while True:
                try:
                    if stage == 0:
                        department_value = _choose("部门", labels)
                    elif stage == 1:
                        tenant_value = _choose(
                            "租户",
                            [(item.name, item) for item in department_value.tenants],
                        )
                    elif stage == 2:
                        scopes: List[Tuple[str, Optional[Team]]] = [
                            (f"{tenant_value.name}（租户级）", None)
                        ]
                        scopes.extend(
                            (
                                item.name if item.selectable else f"{item.name}（禁选）",
                                item,
                            )
                            for item in tenant_value.teams
                        )
                        team_value = _choose(
                            "团队",
                            scopes,
                            style_for=lambda item: (
                                "bold blue"
                                if item is None
                                else "red" if not item.selectable else None
                            ),
                        )
                        if team_value is not None and not team_value.selectable:
                            console.print(
                                f"团队 {team_value.name!r} 当前状态为 "
                                f"{team_value.status!r}，不可选择",
                                markup=False,
                            )
                            continue
                    else:
                        console.print(
                            f"请确认选择：部门 {department_value.name} → "
                            f"租户 {tenant_value.name} → "
                            f"{team_value.name if team_value else '租户级'}",
                            markup=False,
                        )
                        confirmation = msg.prompt(
                            "确认切换？（y 确认，b 返回，q 取消）"
                        ).strip().lower()
                        if confirmation == "y":
                            break
                        if confirmation == "b":
                            raise _Back()
                        if confirmation == "q":
                            raise _Cancel()
                        msg.detail("请输入 y、b 或 q")
                        continue
                    stage += 1
                except _Back:
                    if stage == 0:
                        msg.detail("已经是第一级，请选择部门或输入 q 取消")
                    else:
                        stage -= 1
                except _Cancel:
                    msg.detail("已取消业务切换")
                    return
            selected_department = department_value.id
            selected_tenant = tenant_value.id
            selected_team = team_value.id if team_value else ""

        selection = runtime.business.select(
            profile=runtime.config.current_name,
            username=credentials.username,
            department_id=selected_department,
            tenant_id=str(selected_tenant),
            team_id=selected_team,
        )
        runtime.credentials.save(
            replace(
                credentials,
                business_id=selection.business_id,
            )
        )
        msg.success("当前业务上下文已切换：")
        _print_selection(selection)
        if runtime.config.auto_ping:
            msg.ping_status(ping.auto_start(runtime))
    except Exception as exc:
        fail(exc)


@business_app.command("refresh")
def refresh_business(context: typer.Context) -> None:
    """打开 Edge 刷新当前环境的业务目录。"""
    try:
        runtime = runtime_from_context(context)
        previous_updated_at = runtime.business.updated_at(
            runtime.config.current_name
        )
        credentials = runtime.auth.login()
        runtime.business.catalog(
            runtime.config.current_name, credentials.username
        )
        if runtime.business.updated_at(
            runtime.config.current_name
        ) <= previous_updated_at:
            raise BusinessError(
                "未能从 Edge 刷新 ai-businessList，请检查登录页面缓存"
            )
        msg.success("业务目录已刷新")
    except Exception as exc:
        fail(exc)
