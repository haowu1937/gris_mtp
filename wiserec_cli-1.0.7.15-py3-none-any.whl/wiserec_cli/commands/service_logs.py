"""服务日志的主机、类别和文件选择流程。"""
from __future__ import annotations

import sys
from contextlib import redirect_stdout
from typing import Optional

import click
import typer
from rich.table import Table
from rich.text import Text

from .. import messages as msg
from ..errors import ApiError
from ..output import console, error_console
from ..services.service import ServiceCatalog
from .common import fail, runtime_from_context

LOG_TYPES = {
    'infer-python': ('run', 'interface', 'metrics', 'engine', 'ascend', 'mslite', 'alarm'),
    'rtc': ('rtc', 'run', 'interface', 'dcs', 'metrics', 'gc', 'interface_manager',
            'interface_extend', 'engine', 'monitor', 'catalina', 'dmq'),
}


def can_prompt():
    return sys.stdin.isatty()


def choose(items, label, option, interactive, render_table):
    if not items:
        raise ValueError(f'没有可用的{label}')
    if len(items) == 1:
        return items[0]
    if not interactive:
        raise ValueError(f'{label}无法唯一确定，请指定 {option}；同名候选需在交互终端选择')
    error_console.print(render_table(items))
    while True:
        with redirect_stdout(sys.stderr):
            answer = click.prompt(msg.prompt_text(f'请选择{label}'), err=True)
        try:
            index = click.IntRange(1, len(items)).convert(answer, None, None)
            break
        except click.BadParameter:
            msg.error(f'请输入 1 到 {len(items)} 之间的整数编号')
    return items[index - 1]


def log_type_table(types):
    table = Table('编号', '日志类别', header_style='bold cyan')
    for index, log_type in enumerate(types, 1):
        table.add_row(str(index), Text(log_type))
    return table


def host_table(hosts):
    from .service import display_value
    columns = (
        ('集群', 'clusterName'), ('pod名称', 'nodeName'), ('podIP', 'nodeHost'),
        ('主机IP', 'hostIp'), ('状态', 'health_status'),
        ('创建时间', 'create_time'), ('更新时间', 'update_time'),
    )
    table = Table(show_header=True, header_style='bold cyan')
    table.add_column('编号', justify='right', no_wrap=True)
    for title, _ in columns:
        table.add_column(title, min_width=1, overflow='fold')
    for index, host in enumerate(hosts, 1):
        table.add_row(str(index), *(Text(display_value(field, host)) for _, field in columns))
    return table


def select_host(query, interactive):
    page = 1
    cache = {}
    while True:
        if page not in cache:
            cache[page] = query(page)
        result = cache[page]
        items = result['items']
        if not items:
            raise ApiError('主机列表为空，请核对服务或重试')
        if result['total'] == 1 and len(items) == 1:
            return items[0]
        if not interactive:
            raise ValueError('主机无法唯一确定，请同时指定 --pod 和 --cluster-name')
        msg.detail(f"主机列表 · 第 {page} 页 · 共 {result['total']} 条")
        error_console.print(host_table(items))
        with redirect_stdout(sys.stderr):
            answer = str(click.prompt(msg.prompt_text('输入编号选择，n 下一页，p 上一页，q 退出'), err=True)).strip().lower()
        if answer == 'q':
            raise click.Abort()
        if answer == 'n':
            if page * result['pageSize'] < result['total']:
                page += 1
            else:
                msg.detail('已经是最后一页')
        elif answer == 'p':
            if page > 1:
                page -= 1
            else:
                msg.detail('已经是第一页')
        elif answer.isdecimal() and 1 <= int(answer) <= len(items):
            return items[int(answer) - 1]
        else:
            msg.detail('请输入当前页有效编号或 n、p、q')


def file_table(files):
    from .service import _text, _time
    table = Table('编号', '文件名称', '大小', '修改时间')
    for index, item in enumerate(files, 1):
        value = item.get('updateTime')
        # 无时区的 ls 风格日期保留原值。
        timestamp = _time(value) if isinstance(value, str) and 'T' in value else _text(value)
        table.add_row(str(index), Text(_text(item.get('fileName'))),
                      Text(_text(item.get('fileSize'))), Text(timestamp))
    return table


def service_logs(
    context: typer.Context,
    service_id: str = typer.Argument(..., help='服务 ID'),
    pod: Optional[str] = typer.Option(None, '--pod', help='Pod 名称'),
    cluster_name: Optional[str] = typer.Option(None, '--cluster-name', help='集群名称，必须与 --pod 同时提供'),
    log_type: Optional[str] = typer.Option(None, '--type', help='日志类别'),
    file_name: Optional[str] = typer.Option(None, '--file', help='日志文件名称'),
    keywords: Optional[list[str]] = typer.Option(None, '--keyword', '-k', help='关键词，可重复'),
    lines: int = typer.Option(200, '--lines', '-n', min=1, help='查询行数'),
    list_only: bool = typer.Option(False, '--list', help='只显示日志文件列表'),
    no_input: bool = typer.Option(False, '--no-input', help='禁止交互选择'),
    search_order: str = typer.Option('tail', '--search-order', help='检索顺序'),
    grep_scope: str = typer.Option('C', '--grep-scope', help='关键词范围'),
    grep_line: int = typer.Option(0, '--grep-line', min=0, help='关键词上下文行数'),
):
    """选择服务主机和文件并查看日志"""
    from .service import _required_text, _selected_business
    try:
        service_id = _required_text(service_id, '服务 ID')
        if (pod is None) != (cluster_name is None):
            raise ValueError('--pod 与 --cluster-name 必须同时提供')
        for value, label in ((cluster_name, '集群名称'), (pod, 'Pod'), (log_type, '日志类别'), (file_name, '文件名称')):
            if value is not None:
                _required_text(value, label)
        search_order = _required_text(search_order, '检索顺序')
        grep_scope = _required_text(grep_scope, '关键词范围')
        if any(not word.strip() for word in keywords or []):
            raise ValueError('关键词不能为空白')
        body_options = ('file_name', 'keywords', 'lines', 'search_order', 'grep_scope', 'grep_line')
        # Typer may use its bundled Click enum; compare the public source name.
        if list_only and any(getattr(context.get_parameter_source(name), 'name', None) == 'COMMANDLINE'
                             for name in body_options):
            raise ValueError('--list 不能与文件、关键词、行数或正文检索选项同时使用')
        interactive = not no_input and can_prompt()
        runtime = runtime_from_context(context)

        def call(operation):
            def query(client):
                _selected_business(runtime, client)
                return operation(ServiceCatalog(client))
            with redirect_stdout(sys.stderr):
                return runtime.authenticated_call(query)

        def query_hosts(page):
            return call(lambda service: service.list_hosts(service_id, page))

        if pod is not None:
            first_page = query_hosts(1)
            if not first_page['items']:
                raise ApiError('主机列表为空，无法获取 infraType')
            host = {'nodeName': pod.strip(), 'clusterName': cluster_name.strip(),
                    'infraType': first_page['items'][0].get('infraType')}
        else:
            host = select_host(query_hosts, interactive)
        for key in ('nodeName', 'clusterName'):
            if not isinstance(host.get(key), str) or not host[key].strip():
                raise ApiError(f'主机缺少有效的 {key}')
        infra = host.get('infraType')
        if infra not in LOG_TYPES:
            raise ValueError(f'不支持的主机 infraType：{infra}')
        types = LOG_TYPES[infra]
        if log_type is None:
            log_type = choose(types, '日志类别', '--type TYPE', interactive, log_type_table)
        elif log_type not in types:
            raise ValueError(f'该主机不支持日志类别 {log_type}，可选：{", ".join(types)}')
        files = call(lambda service: service.list_pod_log_files(
            host['nodeName'], host['clusterName'], log_type, infra_type=infra))
        if list_only:
            console.print(file_table(files))
            if not files:
                msg.detail('暂无日志文件')
            return
        if not files and file_name is None:
            msg.detail('暂无日志文件')
            return
        if file_name is not None:
            files = [item for item in files if item.get('fileName') == file_name]
        selected = choose(files, '日志文件', '--file FILE_NAME', interactive,
                          file_table)
        name = selected.get('fileName')
        if not isinstance(name, str) or not name.strip():
            raise ApiError('日志文件缺少有效的 fileName')
        msg.detail(f"Pod：{host['nodeName']} · 文件：{name} · {search_order} {lines} 行")
        content = call(lambda service: service.search_pod_log(
            host['nodeName'], host['clusterName'], log_type, name, keywords or [],
            lines, search_order, grep_scope, grep_line, infra_type=infra))
        typer.echo(content, nl=False)
    except (KeyboardInterrupt, EOFError, click.Abort):
        msg.detail('已取消')
        raise typer.Exit(130)
    except Exception as exc:
        fail(exc)
