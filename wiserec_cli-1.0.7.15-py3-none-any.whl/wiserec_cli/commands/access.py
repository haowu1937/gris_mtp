"""权限服务接入状态。"""

import typer
from .. import messages as msg
from ..output import print_text, console
from ..access_diagnostics import AccessDiagnostics
from ..access import access_enabled
from .. import __version__
from .common import runtime_from_context, fail

access_app = typer.Typer(no_args_is_help=True, help='检查 CLI 在线访问授权')


@access_app.command('status')
def status(context: typer.Context, diagnose: bool = typer.Option(False, "--diagnose", help="显示权限请求连接、耗时和有限响应头，不输出凭据")):
    """实时检查当前平台账号及环境的访问授权。"""
    try:
        runtime = runtime_from_context(context)
        if diagnose:
            runtime.access_diagnostics = AccessDiagnostics(msg.detail)
            runtime.access_diagnostics.line('CLI 版本', __version__)
            runtime.access_diagnostics.line('配置文件', runtime.config.path)
        settings = runtime.config.access_control
        if not access_enabled(settings):
            msg.detail('已关闭在线权限检查。')
            return
        runtime.authenticated_call(lambda client: None)
        print_text('当前账号已获当前环境访问授权。')
    except Exception as exc:
        fail(exc)
    finally:
        if 'runtime' in locals():
            runtime.access_diagnostics = None
