"""命令共享的运行时依赖与认证重试。"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Optional

from . import messages as msg
from .auth import AuthManager
from .access import check_access
from .business import BusinessStore
from .client import PlatformClient
from .config import ConfigManager
from .credentials import CredentialStore
from .errors import AuthenticationError


class Runtime:
    def __init__(
        self,
        config_path: Optional[Path] = None,
        credential_path: Optional[Path] = None,
        business_path: Optional[Path] = None,
    ):
        self.invocation_command = "unknown"
        self.config = ConfigManager(config_path)
        self.credentials = CredentialStore(credential_path)
        self.business = BusinessStore(business_path)
        from .execution import current
        factory = current().auth_factory or AuthManager
        self.auth = factory(self.config, self.credentials, self.business)

    def authenticated_call(
        self,
        operation: Callable[[PlatformClient], Any],
        *, retry_auth: bool = True,
    ) -> Any:
        for attempt in range(2):
            credentials = self.auth.ensure_credentials(force_refresh=attempt == 1)
            profile = self.config.current_profile()
            selection = self.business.require_selection(
                profile.name, credentials.username
            )
            try:
                check_access(self.config.access_control, profile, credentials, selection,
                             command=getattr(self, "invocation_command", "unknown"),
                             full_command=getattr(self, "full_command", ""),
                             **({"diagnostics": self.access_diagnostics} if getattr(self, "access_diagnostics", None) else {}))
                with PlatformClient(
                    profile=profile,
                    credentials=credentials,
                    timeout_ms=self.config.timeout_ms,
                    retry_times=self.config.retry_times,
                    verify_ssl=self.config.verify_ssl,
                    business_selection=selection,
                    on_platform_success=lambda: self.auth.record_platform_activity(credentials),
                ) as client:
                    return operation(client)
            except AuthenticationError:
                if attempt == 0 and retry_auth:
                    msg.info("服务端认证已失效，将重新打开 Edge 刷新本地认证信息。")
                    continue
                raise
        raise AuthenticationError("重新登录后认证仍然失败")
