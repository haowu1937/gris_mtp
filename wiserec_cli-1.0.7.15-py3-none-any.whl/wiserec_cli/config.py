"""config.json 读取、校验与 profile 管理。"""

from __future__ import annotations

import json
import os
from hashlib import sha256
from importlib import resources
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import quote, urlsplit

from . import __version__
from .access import validate_settings
from .errors import ConfigError
from .models import Profile


def default_config_path() -> Path:
    from .execution import current
    if current().config_path is not None:
        return current().config_path

    configured = os.environ.get("ML_CONFIG")
    if configured:
        return Path(configured).expanduser().resolve()

    preferred = user_config_dir() / "config.json"
    _sync_packaged_config(preferred)

    local_config = Path.cwd() / "config.json"
    if local_config.exists():
        return local_config.resolve()

    return preferred


def _packaged_config_text() -> str:
    """读取当前安装包携带的默认配置。"""
    try:
        return resources.files("wiserec_cli").joinpath(
            "config.json"
        ).read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError) as exc:
        source_config = Path(__file__).resolve().parents[2] / "config.json"
        try:
            return source_config.read_text(encoding="utf-8")
        except FileNotFoundError:
            raise ConfigError(
                "安装包中缺少 config.json，请重新安装 wiserec-cli"
            ) from exc


def _install_packaged_config(destination: Path, template: Optional[str] = None) -> None:
    """将安装包内的默认配置覆盖到用户配置目录。"""
    template = template if template is not None else _packaged_config_text()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(
        f".{destination.name}.{os.getpid()}.tmp"
    )
    temporary.write_text(template, encoding="utf-8")
    temporary.replace(destination)


def _config_marker_path(destination: Path) -> Path:
    return destination.with_name(f".{destination.name}.installed")


def _package_install_stamp() -> str:
    """安装文件时间戳区分相同版本、相同配置的重新安装。"""
    installed = Path(__file__).stat()
    return f"{installed.st_mtime_ns}:{installed.st_ctime_ns}"


def reset_packaged_config() -> Path:
    """安装器入口：更新默认配置，保留环境选择与自动保活设置。"""
    destination = user_config_dir() / "config.json"
    _sync_packaged_config(destination, force=True)
    return destination


def _sync_packaged_config(destination: Path, *, force: bool = False) -> None:
    """更新包内配置时保留用户环境选择与明确设置的自动保活选项。"""
    template = _packaged_config_text()
    signature = f"{__version__}:{sha256(template.encode('utf-8')).hexdigest()}:{_package_install_stamp()}"
    marker = _config_marker_path(destination)
    try:
        installed_signature = marker.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        installed_signature = ""

    if not force and destination.exists() and installed_signature == signature:
        return

    settings = json.loads(template)
    preserved = False
    if destination.exists():
        try:
            previous = json.loads(destination.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ConfigError(
                f"无法读取原配置 {destination}，已保留原文件；请修复配置后重新安装或运行"
            ) from exc
        previous_manager = ConfigManager.__new__(ConfigManager)
        previous_manager.path = destination
        previous_manager._data = previous
        try:
            if not isinstance(previous, dict):
                raise ConfigError("配置文件顶层必须是 JSON 对象")
            previous_manager._validate()
        except (ConfigError, TypeError, ValueError) as exc:
            raise ConfigError(f"原配置无效，已保留 {destination}；请修复配置：{exc}") from exc
        current = previous["current"]
        if not any(item.get("name") == current for item in settings.get("profiles", [])):
            raise ConfigError(
                f"新配置中不存在原环境 {current!r}，已保留 {destination}；"
                "请通过 --config 指定原配置并使用 ml env use 选择新包支持的环境后重试"
            )
        settings["current"] = current
        preserved = True
        for key in ("auto_ping", "ping_interval_minutes"):
            if key in previous.get("auth", {}):
                settings.setdefault("auth", {})[key] = previous["auth"][key]
    candidate = ConfigManager.__new__(ConfigManager)
    candidate.path = destination
    candidate._data = settings
    candidate._validate()
    content = json.dumps(settings, ensure_ascii=False, indent=2) + "\n" if preserved else template
    _install_packaged_config(destination, content)
    temporary = marker.with_name(f".{marker.name}.{os.getpid()}.tmp")
    temporary.write_text(signature + "\n", encoding="utf-8")
    temporary.replace(marker)


def user_config_dir() -> Path:
    from .execution import current
    return current().state_dir or _user_config_dir("ml")


def _user_config_dir(application_name: str) -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
        return root / application_name
    if os.sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / application_name
    root = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return root / application_name


class ConfigManager:
    def __init__(self, path: Optional[Path] = None):
        self.path = (path or default_config_path()).expanduser().resolve()
        self._data = self._read()
        self._validate()
        from .execution import current
        if current().validate_config:
            current().validate_config(self)

    def _read(self) -> Dict[str, Any]:
        try:
            with self.path.open("r", encoding="utf-8") as file:
                value = json.load(file)
        except FileNotFoundError as exc:
            raise ConfigError(
                f"配置文件不存在: {self.path}。可通过 --config 或 ML_CONFIG 指定。"
            ) from exc
        except json.JSONDecodeError as exc:
            raise ConfigError(f"配置文件不是有效的 JSON: {exc}") from exc
        if not isinstance(value, dict):
            raise ConfigError("配置文件顶层必须是 JSON 对象")
        return value

    def _validate(self) -> None:
        validate_settings(self._data.get("access_control"))
        current = self._data.get("current")
        if not isinstance(current, str) or not current:
            raise ConfigError("config.json 中的 current 必须是非空字符串")
        if not isinstance(self._data.get("api", {}), dict):
            raise ConfigError("config.json 中的 api 必须是对象")
        if not isinstance(self._data.get("auth", {}), dict):
            raise ConfigError("config.json 中的 auth 必须是对象")
        if not isinstance(self._data.get("browser", {}), dict):
            raise ConfigError("config.json 中的 browser 必须是对象")
        if not isinstance(
            self._data.get("api", {}).get("verify_ssl", True),
            bool,
        ):
            raise ConfigError("api.verify_ssl 必须是布尔值")
        profiles = self._data.get("profiles")
        if not isinstance(profiles, list) or not profiles:
            raise ConfigError("config.json 中的 profiles 必须是非空数组")
        names = set()
        for item in profiles:
            if not isinstance(item, dict):
                raise ConfigError("profiles 中的每一项都必须是对象")
            name = item.get("name")
            if "alias" in item and (not isinstance(item["alias"], str) or not item["alias"].strip()):
                raise ConfigError("profile.alias 必须是非空字符串")
            endpoint = item.get("api_endpoint")
            parsed = urlsplit(endpoint) if isinstance(endpoint, str) else None
            if not isinstance(name, str) or not name:
                raise ConfigError("profile.name 必须是非空字符串")
            if name in names:
                raise ConfigError(f"profile.name 重复: {name}")
            if not parsed or parsed.scheme not in {"http", "https"} or not parsed.netloc:
                raise ConfigError(f"profile {name!r} 的 api_endpoint 无效")
            if "verify_ssl" in item and not isinstance(item["verify_ssl"], bool):
                raise ConfigError(f"profile {name!r} 的 verify_ssl 必须是布尔值")
            names.add(name)
        if current not in names:
            raise ConfigError(f"profiles 中不存在 current 指定的环境: {current}")
        if self.auth_ttl_seconds <= 0:
            raise ConfigError("auth.expires_in_seconds 必须大于 0")
        auth = self._data.get("auth", {})
        if type(auth.get("auto_ping", True)) is not bool:
            raise ConfigError("auth.auto_ping 必须是布尔值")
        interval = auth.get("ping_interval_minutes", 10)
        if type(interval) is not int or not 1 <= interval <= 20:
            raise ConfigError("auth.ping_interval_minutes 必须是 1 到 20 的整数")
        if self.browser_channel not in {
            "msedge",
            "msedge-beta",
            "msedge-dev",
            "msedge-canary",
        }:
            raise ConfigError("browser.channel 必须是 Microsoft Edge 通道")
        if self.session_probe_timeout_ms <= 0:
            raise ConfigError("browser.session_probe_timeout 必须大于 0")
        if self.login_timeout_ms <= 0:
            raise ConfigError("browser.login_timeout 必须大于 0")
        if self.business_catalog_timeout_ms <= 0:
            raise ConfigError("browser.business_catalog_timeout 必须大于 0")

    @property
    def access_control(self) -> Dict[str, Any]:
        return validate_settings(self._data.get("access_control"))

    @property
    def current_name(self) -> str:
        return str(self._data["current"])

    @property
    def timeout_ms(self) -> int:
        value = self._data.get("api", {}).get("timeout", 30000)
        return int(value) if isinstance(value, (int, float)) and value > 0 else 30000

    @property
    def retry_times(self) -> int:
        value = self._data.get("api", {}).get("retry_times", 3)
        return max(0, int(value)) if isinstance(value, (int, float)) else 3

    @property
    def verify_ssl(self) -> bool:
        return self.verify_ssl_for(self.current_profile())

    def verify_ssl_for(self, profile: Profile) -> bool:
        if profile.verify_ssl is not None:
            return profile.verify_ssl
        return bool(self._data.get("api", {}).get("verify_ssl", True))

    @property
    def auth_ttl_seconds(self) -> int:
        value = self._data.get("auth", {}).get("expires_in_seconds", 1800)
        return int(value) if isinstance(value, (int, float)) else 1800

    @property
    def auto_ping(self) -> bool:
        return self._data.get("auth", {}).get("auto_ping", True)

    @property
    def ping_interval_minutes(self) -> int:
        return self._data.get("auth", {}).get("ping_interval_minutes", 10)

    @property
    def browser_channel(self) -> str:
        value = self._data.get("browser", {}).get("channel", "msedge")
        return str(value)

    @property
    def session_probe_timeout_ms(self) -> int:
        value = self._data.get("browser", {}).get("session_probe_timeout", 5000)
        return int(value) if isinstance(value, (int, float)) else 5000

    @property
    def login_timeout_ms(self) -> int:
        value = self._data.get("browser", {}).get("login_timeout", 300000)
        return int(value) if isinstance(value, (int, float)) else 300000

    @property
    def business_catalog_timeout_ms(self) -> int:
        value = self._data.get("browser", {}).get(
            "business_catalog_timeout", 30000
        )
        return int(value) if isinstance(value, (int, float)) else 30000

    @property
    def browser_profile_root(self) -> Path:
        configured = self._data.get("browser", {}).get("profile_root")
        if isinstance(configured, str) and configured:
            return Path(configured).expanduser().resolve()
        return user_config_dir() / "browser-profiles"

    def browser_profile_dir(self, profile_name: Optional[str] = None) -> Path:
        name = profile_name or self.current_name
        directory_name = "profile-" + quote(name, safe="")
        return self.browser_profile_root / directory_name

    def profiles(self) -> List[Profile]:
        return [
            Profile(
                name=item["name"],
                api_endpoint=item["api_endpoint"],
                output_format=item.get("output_format", "table"),
                verify_ssl=item.get("verify_ssl"),
                alias=item.get("alias", item["name"]),
            )
            for item in self._data["profiles"]
        ]

    def current_profile(self) -> Profile:
        for profile in self.profiles():
            if profile.name == self.current_name:
                return profile
        raise ConfigError(f"找不到当前环境: {self.current_name}")

    def jupyter_settings(self) -> Dict[str, Any]:
        """Jupyter 配置严格限定到当前环境，不从其他环境回退。"""
        for item in self._data["profiles"]:
            if item["name"] == self.current_name:
                value = item.get("jupyter", {})
                if not isinstance(value, dict):
                    raise ConfigError("当前环境 jupyter 必须为对象")
                return dict(value)
        raise ConfigError("当前环境不存在")

    def use_profile(self, name: str) -> Profile:
        target = next((item for item in self.profiles() if item.name == name), None)
        if target is None:
            raise ConfigError(f"不存在 profile: {name}")
        self._data["current"] = name
        self._write()
        return target

    def _write(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8") as file:
            json.dump(self._data, file, ensure_ascii=False, indent=2)
            file.write("\n")
        temporary.replace(self.path)
