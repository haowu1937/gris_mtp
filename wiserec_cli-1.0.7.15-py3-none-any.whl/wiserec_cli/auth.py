"""通过 Edge 登录并管理有有效期的本地认证信息。"""

from __future__ import annotations

import json
import shutil
import sys
import time
from collections import deque
from dataclasses import replace
from pathlib import Path
from typing import Any, Deque, Dict, Optional

from . import messages as msg
from .business import BusinessStore, parse_business_list
from .config import ConfigManager
from .client import PlatformClient
from .credentials import CredentialStore
from .errors import ApiError, AuthenticationError, BusinessError, CredentialError
from .models import Credentials, Profile
from .output import console, print_result
from .login_output import LoginProgress, quiet_node_warnings


def _parse_user_info(response_body: Any) -> Optional[Dict[str, str]]:
    if not isinstance(response_body, dict):
        return None
    result = response_body.get("result")
    if not isinstance(result, dict) or result.get("code") != 0:
        return None
    return {
        "username": str(result.get("username") or ""),
        "cn_name": str(result.get("cnName") or ""),
        "department": str(result.get("department") or ""),
    }


def _wait_for_edge(page: Any, message: str) -> None:
    msg.info(message)
    try:
        page.wait_for_event("close", timeout=0)
    except Exception:
        pass


class BrowserAuthenticator:
    def __init__(
        self,
        store: CredentialStore,
        business_store: Optional[BusinessStore] = None,
    ):
        self.store = store
        self.business_store = business_store

    def login(
        self,
        profile: Profile,
        timeout_ms: int,
        ttl_seconds: int,
        user_data_dir: Path,
        browser_channel: str,
        session_probe_timeout_ms: int,
        login_timeout_ms: int,
        business_catalog_timeout_ms: int = 30000,
        verify_ssl: bool = True,
        show_secrets: bool = False,
    ) -> Credentials:
        progress = LoginProgress(profile.alias)
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise AuthenticationError(
                "未安装 playwright，请运行: py -m pip install playwright"
            ) from exc

        user_info_url = f"{profile.base_url}/ai/user/info"
        user_data_dir.mkdir(parents=True, exist_ok=True)
        with progress, quiet_node_warnings(), sync_playwright() as playwright:
            context = playwright.chromium.launch_persistent_context(
                user_data_dir=str(user_data_dir),
                channel=browser_channel,
                headless=False,
                ignore_https_errors=not verify_ssl,
            )
            page = context.pages[0] if context.pages else context.new_page()
            page.set_default_timeout(timeout_ms)
            captured_headers: Deque[Dict[str, str]] = deque()

            def capture_auth_request(request: Any) -> None:
                request_url = request.url.split("?", 1)[0].rstrip("/")
                if request_url != user_info_url.rstrip("/"):
                    return
                try:
                    headers = request.all_headers()
                except Exception:
                    return
                if self._find_csrftoken(headers):
                    captured_headers.append(headers)

            context.on("request", capture_auth_request)

            try:
                page.goto(
                    profile.api_endpoint,
                    wait_until="domcontentloaded",
                    timeout=timeout_ms,
                )
                progress.update("正在获取用户信息…")
                credentials = self._wait_for_credentials(
                    context=context,
                    profile=profile,
                    user_info_url=user_info_url,
                    ttl_seconds=ttl_seconds,
                    request_timeout_ms=timeout_ms,
                    wait_timeout_ms=min(
                        session_probe_timeout_ms,
                        timeout_ms,
                    ),
                    captured_headers=captured_headers,
                )

                if credentials is None:
                    progress.update("等待浏览器完成登录…")
                    credentials = self._wait_for_credentials(
                        context=context,
                        profile=profile,
                        user_info_url=user_info_url,
                        ttl_seconds=ttl_seconds,
                        request_timeout_ms=timeout_ms,
                        wait_timeout_ms=login_timeout_ms,
                        captured_headers=captured_headers,
                        progress=progress,
                    )
                if credentials is None:
                    raise AuthenticationError(
                        f"等待登录超时（{login_timeout_ms // 1000} 秒），仍未获取到"
                        "有效的 Cookie、csrftoken 和用户信息"
                    )

                progress.update("正在确认业务信息…")
                business_warning = self._refresh_business_catalog(
                    context,
                    profile,
                    credentials,
                    business_catalog_timeout_ms,
                )
                credentials = replace(
                    credentials,
                    business_id=self._read_local_storage(
                        context, "ai-businessId"
                    ),
                )
                self.store.save(credentials)
                business_id = "未获取"
                if self.business_store is not None:
                    try:
                        business_id = self.business_store.require_selection(
                            profile.name, credentials.username
                        ).business_id
                    except BusinessError:
                        pass
                context.close()
                progress.stop()
                msg.success("登录成功，用户信息如下：")
                print_result(
                    {
                        "环境": progress.alias,
                        "账号": credentials.username or "未获取",
                        "中文名": credentials.cn_name or "未获取",
                        "部门": credentials.department or "未获取",
                        "businessId": business_id,
                    }
                )
                if business_id == "未获取" and not business_warning:
                    msg.info("尚未选择业务，请执行 ml business list 查看并使用 ml business use 选择业务")
                if business_warning:
                    msg.warning(business_warning)
                if show_secrets:
                    print(f"cookie: {credentials.cookie}")
                    print(f"csrftoken: {credentials.csrftoken}")
                return credentials
            except Exception as exc:
                progress.stop()
                if page.is_closed():
                    raise
                msg.error(f"登录失败: {exc}")
                _wait_for_edge(
                    page,
                    "Edge 将保持打开；请检查页面，完成后手动关闭 Edge。",
                )
                raise

    @staticmethod
    def _read_local_storage(context: Any, key: str) -> str:
        for page in reversed(context.pages):
            if page.is_closed():
                continue
            try:
                value = page.evaluate(
                    f"() => localStorage.getItem({json.dumps(key)})"
                )
            except Exception:
                continue
            if value is not None:
                return str(value)
        return ""

    def _refresh_business_catalog(
        self,
        context: Any,
        profile: Profile,
        credentials: Credentials,
        wait_timeout_ms: int,
    ) -> str:
        if self.business_store is None:
            return ""
        deadline = time.monotonic() + wait_timeout_ms / 1000
        last_error = ""

        while time.monotonic() < deadline:
            raw_business_list = self._read_local_storage(
                context, "ai-businessList"
            )
            if raw_business_list:
                try:
                    departments = parse_business_list(raw_business_list)
                    self.business_store.refresh(
                        profile=profile.name,
                        username=credentials.username,
                        departments=departments,
                        browser_business_id=self._read_local_storage(
                            context, "ai-businessId"
                        ),
                    )
                    return ""
                except Exception as exc:
                    last_error = str(exc)

            open_pages = [
                page for page in context.pages if not page.is_closed()
            ]
            if not open_pages:
                return "Edge 已关闭，未能读取 ai-businessList"
            remaining_ms = int((deadline - time.monotonic()) * 1000)
            if remaining_ms <= 0:
                break
            open_pages[-1].wait_for_timeout(min(250, remaining_ms))

        if last_error:
            return f"等待 ai-businessList 超时，最后一次解析失败: {last_error}"
        return "等待 ai-businessList 超时，请运行 ml business refresh 后重试"

    def _wait_for_credentials(
        self,
        context: Any,
        profile: Profile,
        user_info_url: str,
        ttl_seconds: int,
        request_timeout_ms: int,
        wait_timeout_ms: int,
        captured_headers: Deque[Dict[str, str]],
        progress=None,
    ) -> Optional[Credentials]:
        deadline = time.monotonic() + wait_timeout_ms / 1000
        while time.monotonic() < deadline:
            while captured_headers:
                if progress is not None:
                    progress.update("正在获取用户信息…")
                credentials = self._credentials_from_headers(
                    context=context,
                    profile=profile,
                    user_info_url=user_info_url,
                    ttl_seconds=ttl_seconds,
                    request_timeout_ms=request_timeout_ms,
                    captured_headers=captured_headers.popleft(),
                )
                if credentials is not None:
                    return credentials
                if progress is not None:
                    progress.update("等待浏览器完成登录…")

            open_pages = [page for page in context.pages if not page.is_closed()]
            if not open_pages:
                raise AuthenticationError("Edge 已关闭，未能完成登录认证")
            remaining_ms = int((deadline - time.monotonic()) * 1000)
            if remaining_ms <= 0:
                break
            open_pages[-1].wait_for_timeout(min(250, remaining_ms))
        return None

    @staticmethod
    def _find_csrftoken(headers: Dict[str, str]) -> str:
        normalized = {str(key).lower(): value for key, value in headers.items()}
        return str(
            normalized.get("csrftoken")
            or normalized.get("x-csrftoken")
            or normalized.get("x-csrf-token")
            or ""
        )

    def _credentials_from_headers(
        self,
        context: Any,
        profile: Profile,
        user_info_url: str,
        ttl_seconds: int,
        request_timeout_ms: int,
        captured_headers: Dict[str, str],
    ) -> Optional[Credentials]:

        cookies = context.cookies(user_info_url)
        cookie = "; ".join(
            f"{item['name']}={item['value']}" for item in cookies
        )
        csrftoken = self._find_csrftoken(captured_headers)
        if not cookie or not csrftoken:
            return None

        try:
            response = context.request.get(
                user_info_url,
                headers={
                    "cookie": cookie,
                    "csrftoken": csrftoken,
                    "referer": profile.api_endpoint,
                },
                timeout=request_timeout_ms,
            )
            response_text = response.text()
        except Exception:
            return None
        if not response.ok:
            return None
        try:
            user_info = _parse_user_info(json.loads(response_text))
        except json.JSONDecodeError:
            return None
        if user_info is None:
            return None

        return Credentials.create(
            profile=profile.name,
            cookie=cookie,
            csrftoken=csrftoken,
            username=user_info["username"],
            cn_name=user_info["cn_name"],
            department=user_info["department"],
            ttl_seconds=ttl_seconds,
        )


class AuthManager:
    def __init__(
        self,
        config: ConfigManager,
        store: CredentialStore,
        business_store: Optional[BusinessStore] = None,
    ):
        self.config = config
        self.store = store
        self.business_store = business_store
        self.browser = BrowserAuthenticator(store, business_store)

    def _probe_cached_credentials(
        self, profile: Profile, credentials: Credentials,
    ) -> bool:
        """只在本地空闲超时后，核实平台是否仍接受现有凭据。"""
        selection = None
        if self.business_store is not None:
            try:
                selection = self.business_store.selection(
                    profile.name, credentials.username
                )
            except BusinessError:
                pass
        with PlatformClient(
            profile=profile,
            credentials=credentials,
            timeout_ms=self.config.timeout_ms,
            retry_times=self.config.retry_times,
            verify_ssl=self.config.verify_ssl_for(profile),
            business_selection=selection,
        ) as client:
            payload = client.request("GET", "/ai/user/info")
        info = _parse_user_info(payload)
        if info is not None and info["username"]:
            return info["username"] == credentials.username
        result = payload.get("result") if isinstance(payload, dict) else None
        code = result.get("code") if isinstance(result, dict) else None
        if isinstance(code, (int, str)) and code in {
            401, 403, 419, 440, "UNAUTHORIZED", "SESSION_EXPIRED",
        }:
            return False
        raise ApiError("认证校验返回异常，无法确认登录状态，请稍后重试")

    def record_platform_activity(self, credentials: Credentials) -> None:
        """平台请求已成功；续期失败不应把已完成的业务操作报成失败。"""
        try:
            current = self.store.extend_if_current(credentials, self.config.auth_ttl_seconds)
            if (current.username, current.cookie, current.csrftoken) == (
                credentials.username, credentials.cookie, credentials.csrftoken
            ):
                from .ping import mark_platform_activity
                mark_platform_activity(self.store, credentials.profile)
        except (OSError, CredentialError, ValueError) as exc:
            msg.warning(f"无法保存本地认证续期信息：{exc}")

    def ensure_credentials(self, force_refresh: bool = False) -> Credentials:
        profile = self.config.current_profile()
        credentials = self.store.load(profile.name)

        if force_refresh:
            msg.detail(f"正在刷新环境 {profile.name!r} 的认证信息...")
        elif credentials is None:
            msg.info(f"环境 {profile.name!r} 尚未登录，将打开 Edge 获取认证信息。")
        elif credentials.is_expired():
            msg.detail(f"环境 {profile.name!r} 的本地认证空闲时间已到，正在校验平台会话...")
            try:
                if self._probe_cached_credentials(profile, credentials):
                    return self.store.extend_if_current(
                        credentials, self.config.auth_ttl_seconds
                    )
            except AuthenticationError:
                pass
            msg.info("平台会话已失效，将打开 Edge 重新获取认证信息。")
        else:
            return credentials

        return self.browser.login(
            profile=profile,
            timeout_ms=self.config.timeout_ms,
            ttl_seconds=self.config.auth_ttl_seconds,
            user_data_dir=self.config.browser_profile_dir(profile.name),
            browser_channel=self.config.browser_channel,
            session_probe_timeout_ms=self.config.session_probe_timeout_ms,
            login_timeout_ms=self.config.login_timeout_ms,
            business_catalog_timeout_ms=self.config.business_catalog_timeout_ms,
            verify_ssl=self.config.verify_ssl_for(profile),
        )

    def login(self, show_secrets: bool = False) -> Credentials:
        profile = self.config.current_profile()
        return self.browser.login(
            profile=profile,
            timeout_ms=self.config.timeout_ms,
            ttl_seconds=self.config.auth_ttl_seconds,
            user_data_dir=self.config.browser_profile_dir(profile.name),
            browser_channel=self.config.browser_channel,
            session_probe_timeout_ms=self.config.session_probe_timeout_ms,
            login_timeout_ms=self.config.login_timeout_ms,
            business_catalog_timeout_ms=self.config.business_catalog_timeout_ms,
            verify_ssl=self.config.verify_ssl_for(profile),
            show_secrets=show_secrets,
        )

    def logout(
        self,
        all_profiles: bool = False,
        forget_browser: bool = False,
    ) -> None:
        from .webstudio.cache import ConnectionCache
        ConnectionCache.clear(self.store.path, None if all_profiles else self.config.current_name)
        if all_profiles:
            self.store.delete()
        else:
            self.store.delete(self.config.current_name)
        if forget_browser:
            target = (
                self.config.browser_profile_root
                if all_profiles
                else self.config.browser_profile_dir()
            )
            if target.exists():
                shutil.rmtree(target)

    def status(self) -> Credentials:
        credentials = self.store.load(self.config.current_name)
        if credentials is None:
            raise CredentialError(f"环境 {self.config.current_name!r} 尚未登录")
        return credentials
